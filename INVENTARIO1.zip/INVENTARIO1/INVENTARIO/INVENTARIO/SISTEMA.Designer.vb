﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SISTEMA
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.CLIENTESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REGISTRODECLIENTESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PRODUCTOSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REGISTRODEPRODUCTOSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INGRESODEMERCADERIAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PROVEEDORESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REGISTRODEPROVEEDORESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VENDEDORESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REGISTRODEVENDEDORESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FACTURACIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CONSUMIDORFINALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CREDITOFISCALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTESESTANDARESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DETALLEDEPRODUCTOINGRESADOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTEDESALIDADEPRODUCTOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTEDECOMPRASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTEDEVENTASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTEDEPRODUCTOSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OPCIONESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SALIRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.USUARIOSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NUEVOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CONSULTASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CONSULTADEPRODUCTOSToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(876, 452)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(13, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "0"
        '
        'Timer1
        '
        '
        'CLIENTESToolStripMenuItem
        '
        Me.CLIENTESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REGISTRODECLIENTESToolStripMenuItem})
        Me.CLIENTESToolStripMenuItem.Name = "CLIENTESToolStripMenuItem"
        Me.CLIENTESToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.CLIENTESToolStripMenuItem.Text = "CLIENTES"
        '
        'REGISTRODECLIENTESToolStripMenuItem
        '
        Me.REGISTRODECLIENTESToolStripMenuItem.Name = "REGISTRODECLIENTESToolStripMenuItem"
        Me.REGISTRODECLIENTESToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.REGISTRODECLIENTESToolStripMenuItem.Text = "REGISTRO DE CLIENTES"
        '
        'PRODUCTOSToolStripMenuItem
        '
        Me.PRODUCTOSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REGISTRODEPRODUCTOSToolStripMenuItem, Me.INGRESODEMERCADERIAToolStripMenuItem})
        Me.PRODUCTOSToolStripMenuItem.Name = "PRODUCTOSToolStripMenuItem"
        Me.PRODUCTOSToolStripMenuItem.Size = New System.Drawing.Size(87, 20)
        Me.PRODUCTOSToolStripMenuItem.Text = "PRODUCTOS"
        '
        'REGISTRODEPRODUCTOSToolStripMenuItem
        '
        Me.REGISTRODEPRODUCTOSToolStripMenuItem.Name = "REGISTRODEPRODUCTOSToolStripMenuItem"
        Me.REGISTRODEPRODUCTOSToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.REGISTRODEPRODUCTOSToolStripMenuItem.Text = "REGISTRO DE PRODUCTOS"
        '
        'INGRESODEMERCADERIAToolStripMenuItem
        '
        Me.INGRESODEMERCADERIAToolStripMenuItem.Name = "INGRESODEMERCADERIAToolStripMenuItem"
        Me.INGRESODEMERCADERIAToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.INGRESODEMERCADERIAToolStripMenuItem.Text = "INGRESO DE MERCADERIA"
        '
        'PROVEEDORESToolStripMenuItem
        '
        Me.PROVEEDORESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REGISTRODEPROVEEDORESToolStripMenuItem})
        Me.PROVEEDORESToolStripMenuItem.Name = "PROVEEDORESToolStripMenuItem"
        Me.PROVEEDORESToolStripMenuItem.Size = New System.Drawing.Size(97, 20)
        Me.PROVEEDORESToolStripMenuItem.Text = "PROVEEDORES"
        '
        'REGISTRODEPROVEEDORESToolStripMenuItem
        '
        Me.REGISTRODEPROVEEDORESToolStripMenuItem.Name = "REGISTRODEPROVEEDORESToolStripMenuItem"
        Me.REGISTRODEPROVEEDORESToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.REGISTRODEPROVEEDORESToolStripMenuItem.Text = "REGISTRO DE PROVEEDORES"
        '
        'VENDEDORESToolStripMenuItem
        '
        Me.VENDEDORESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REGISTRODEVENDEDORESToolStripMenuItem})
        Me.VENDEDORESToolStripMenuItem.Name = "VENDEDORESToolStripMenuItem"
        Me.VENDEDORESToolStripMenuItem.Size = New System.Drawing.Size(91, 20)
        Me.VENDEDORESToolStripMenuItem.Text = "VENDEDORES"
        '
        'REGISTRODEVENDEDORESToolStripMenuItem
        '
        Me.REGISTRODEVENDEDORESToolStripMenuItem.Name = "REGISTRODEVENDEDORESToolStripMenuItem"
        Me.REGISTRODEVENDEDORESToolStripMenuItem.Size = New System.Drawing.Size(219, 22)
        Me.REGISTRODEVENDEDORESToolStripMenuItem.Text = "REGISTRO DE VENDEDORES"
        '
        'FACTURACIONToolStripMenuItem
        '
        Me.FACTURACIONToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CONSUMIDORFINALToolStripMenuItem, Me.CREDITOFISCALToolStripMenuItem})
        Me.FACTURACIONToolStripMenuItem.Name = "FACTURACIONToolStripMenuItem"
        Me.FACTURACIONToolStripMenuItem.Size = New System.Drawing.Size(99, 20)
        Me.FACTURACIONToolStripMenuItem.Text = "FACTURACION"
        '
        'CONSUMIDORFINALToolStripMenuItem
        '
        Me.CONSUMIDORFINALToolStripMenuItem.Name = "CONSUMIDORFINALToolStripMenuItem"
        Me.CONSUMIDORFINALToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.CONSUMIDORFINALToolStripMenuItem.Text = "CONSUMIDOR FINAL"
        '
        'CREDITOFISCALToolStripMenuItem
        '
        Me.CREDITOFISCALToolStripMenuItem.Name = "CREDITOFISCALToolStripMenuItem"
        Me.CREDITOFISCALToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.CREDITOFISCALToolStripMenuItem.Text = "CREDITO FISCAL"
        '
        'REPORTESToolStripMenuItem
        '
        Me.REPORTESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REPORTESESTANDARESToolStripMenuItem})
        Me.REPORTESToolStripMenuItem.Name = "REPORTESToolStripMenuItem"
        Me.REPORTESToolStripMenuItem.Size = New System.Drawing.Size(73, 20)
        Me.REPORTESToolStripMenuItem.Text = "REPORTES"
        '
        'REPORTESESTANDARESToolStripMenuItem
        '
        Me.REPORTESESTANDARESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DETALLEDEPRODUCTOINGRESADOToolStripMenuItem, Me.REPORTEDESALIDADEPRODUCTOToolStripMenuItem, Me.REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem, Me.REPORTEDECOMPRASToolStripMenuItem, Me.REPORTEDEVENTASToolStripMenuItem, Me.REPORTEDEPRODUCTOSToolStripMenuItem})
        Me.REPORTESESTANDARESToolStripMenuItem.Name = "REPORTESESTANDARESToolStripMenuItem"
        Me.REPORTESESTANDARESToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.REPORTESESTANDARESToolStripMenuItem.Text = "REPORTES ESTANDARES"
        '
        'DETALLEDEPRODUCTOINGRESADOToolStripMenuItem
        '
        Me.DETALLEDEPRODUCTOINGRESADOToolStripMenuItem.Name = "DETALLEDEPRODUCTOINGRESADOToolStripMenuItem"
        Me.DETALLEDEPRODUCTOINGRESADOToolStripMenuItem.Size = New System.Drawing.Size(305, 22)
        Me.DETALLEDEPRODUCTOINGRESADOToolStripMenuItem.Text = "REPORTE DE EXISTENCIAS Y UBICACION"
        '
        'REPORTEDESALIDADEPRODUCTOToolStripMenuItem
        '
        Me.REPORTEDESALIDADEPRODUCTOToolStripMenuItem.Name = "REPORTEDESALIDADEPRODUCTOToolStripMenuItem"
        Me.REPORTEDESALIDADEPRODUCTOToolStripMenuItem.Size = New System.Drawing.Size(305, 22)
        Me.REPORTEDESALIDADEPRODUCTOToolStripMenuItem.Text = "REPORTE DE PRODUCTOS POR PROVEEDOR"
        '
        'REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem
        '
        Me.REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem.Name = "REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem"
        Me.REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem.Size = New System.Drawing.Size(305, 22)
        Me.REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem.Text = "REPORTE DE UBICACION DE PRODUCTO"
        '
        'REPORTEDECOMPRASToolStripMenuItem
        '
        Me.REPORTEDECOMPRASToolStripMenuItem.Name = "REPORTEDECOMPRASToolStripMenuItem"
        Me.REPORTEDECOMPRASToolStripMenuItem.Size = New System.Drawing.Size(305, 22)
        Me.REPORTEDECOMPRASToolStripMenuItem.Text = "REPORTE DE COMPRAS "
        '
        'REPORTEDEVENTASToolStripMenuItem
        '
        Me.REPORTEDEVENTASToolStripMenuItem.Name = "REPORTEDEVENTASToolStripMenuItem"
        Me.REPORTEDEVENTASToolStripMenuItem.Size = New System.Drawing.Size(305, 22)
        Me.REPORTEDEVENTASToolStripMenuItem.Text = "REPORTE DE VENTAS"
        '
        'REPORTEDEPRODUCTOSToolStripMenuItem
        '
        Me.REPORTEDEPRODUCTOSToolStripMenuItem.Name = "REPORTEDEPRODUCTOSToolStripMenuItem"
        Me.REPORTEDEPRODUCTOSToolStripMenuItem.Size = New System.Drawing.Size(305, 22)
        Me.REPORTEDEPRODUCTOSToolStripMenuItem.Text = "REPORTE DE PRODUCTOS MENSUAL"
        '
        'OPCIONESToolStripMenuItem
        '
        Me.OPCIONESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SALIRToolStripMenuItem})
        Me.OPCIONESToolStripMenuItem.Name = "OPCIONESToolStripMenuItem"
        Me.OPCIONESToolStripMenuItem.Size = New System.Drawing.Size(76, 20)
        Me.OPCIONESToolStripMenuItem.Text = "OPCIONES"
        '
        'SALIRToolStripMenuItem
        '
        Me.SALIRToolStripMenuItem.Name = "SALIRToolStripMenuItem"
        Me.SALIRToolStripMenuItem.Size = New System.Drawing.Size(104, 22)
        Me.SALIRToolStripMenuItem.Text = "SALIR"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CLIENTESToolStripMenuItem, Me.CONSULTASToolStripMenuItem, Me.PRODUCTOSToolStripMenuItem, Me.PROVEEDORESToolStripMenuItem, Me.VENDEDORESToolStripMenuItem, Me.FACTURACIONToolStripMenuItem, Me.REPORTESToolStripMenuItem, Me.USUARIOSToolStripMenuItem, Me.OPCIONESToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1024, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'USUARIOSToolStripMenuItem
        '
        Me.USUARIOSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NUEVOToolStripMenuItem})
        Me.USUARIOSToolStripMenuItem.Name = "USUARIOSToolStripMenuItem"
        Me.USUARIOSToolStripMenuItem.Size = New System.Drawing.Size(74, 20)
        Me.USUARIOSToolStripMenuItem.Text = "USUARIOS"
        '
        'NUEVOToolStripMenuItem
        '
        Me.NUEVOToolStripMenuItem.Name = "NUEVOToolStripMenuItem"
        Me.NUEVOToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.NUEVOToolStripMenuItem.Text = "NUEVO"
        '
        'CONSULTASToolStripMenuItem
        '
        Me.CONSULTASToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CONSULTADEPRODUCTOSToolStripMenuItem1, Me.CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem})
        Me.CONSULTASToolStripMenuItem.Name = "CONSULTASToolStripMenuItem"
        Me.CONSULTASToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.CONSULTASToolStripMenuItem.Text = "CONSULTAS"
        '
        'CONSULTADEPRODUCTOSToolStripMenuItem1
        '
        Me.CONSULTADEPRODUCTOSToolStripMenuItem1.Name = "CONSULTADEPRODUCTOSToolStripMenuItem1"
        Me.CONSULTADEPRODUCTOSToolStripMenuItem1.Size = New System.Drawing.Size(316, 22)
        Me.CONSULTADEPRODUCTOSToolStripMenuItem1.Text = "CONSULTA DE PRODUCTOS"
        '
        'CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem
        '
        Me.CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem.Name = "CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem"
        Me.CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem.Size = New System.Drawing.Size(316, 22)
        Me.CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem.Text = "CONSULTA DE PRODUCTOS POR PROVEEDOR"
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.Image = Global.INVENTARIO.My.Resources.Resources.descarga
        Me.PictureBox3.Location = New System.Drawing.Point(0, 27)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(1073, 561)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 6
        Me.PictureBox3.TabStop = False
        '
        'SISTEMA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.INVENTARIO.My.Resources.Resources.gzTYsh
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1024, 586)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label1)
        Me.HelpButton = True
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "SISTEMA"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SISTEMA"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents CLIENTESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REGISTRODECLIENTESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PRODUCTOSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REGISTRODEPRODUCTOSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INGRESODEMERCADERIAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PROVEEDORESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REGISTRODEPROVEEDORESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VENDEDORESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REGISTRODEVENDEDORESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FACTURACIONToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CONSUMIDORFINALToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CREDITOFISCALToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTESESTANDARESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DETALLEDEPRODUCTOINGRESADOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTEDESALIDADEPRODUCTOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTEDECOMPRASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTEDEVENTASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OPCIONESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SALIRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents USUARIOSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NUEVOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REPORTEDEPRODUCTOSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CONSULTASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CONSULTADEPRODUCTOSToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class

﻿Public Class CONSULTA_DE_PRODUCTOS

    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        toolTip1.SetToolTip(Button1, "Buscar")
    End Sub

    Private Function toolTip1() As Object
        Throw New NotImplementedException
    End Function

End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SISTEMA
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.INVERCONCA = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'INVERCONCA
        '
        Me.INVERCONCA.AutoSize = True
        Me.INVERCONCA.BackColor = System.Drawing.SystemColors.Info
        Me.INVERCONCA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.INVERCONCA.Font = New System.Drawing.Font("Segoe Print", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.INVERCONCA.Location = New System.Drawing.Point(294, 127)
        Me.INVERCONCA.Name = "INVERCONCA"
        Me.INVERCONCA.Size = New System.Drawing.Size(213, 49)
        Me.INVERCONCA.TabIndex = 0
        Me.INVERCONCA.Text = "INVERCONCA"
        '
        'SISTEMA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.INVERCONCA)
        Me.Name = "SISTEMA"
        Me.Text = "SISTEMA"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents INVERCONCA As Label
End Class

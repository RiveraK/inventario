﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "UTEC" And TextBox2.Text = "ADMIN" Then
            SISTEMA.Show()

        Else
            MsgBox "usuario o contraseña incorrecta"
            TextBox1.Text = ""
            TextBox2.Text = ""
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If MsgBox("desea salir del programa...?", vbQuestion + vbYesNo, "Salir") = vbYes Then
            End
        End If
    End Sub
End Class

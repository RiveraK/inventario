﻿Public Class PRODUCTOS

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub PRODUCTOS_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
﻿Public Class SISTEMA
    Private Sub SALIRToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SALIRToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub REGISTRODECLIENTESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REGISTRODECLIENTESToolStripMenuItem.Click
        CLIENTES.ShowDialog()
    End Sub

    Private Sub REGISTRODEPRODUCTOSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REGISTRODEPRODUCTOSToolStripMenuItem.Click
        PRODUCTOS.ShowDialog()
    End Sub

    Private Sub REGISTRODEPROVEEDORESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REGISTRODEPROVEEDORESToolStripMenuItem.Click
        PROVEEDORES.ShowDialog()
    End Sub

    Private Sub REGISTRODEVENDEDORESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REGISTRODEVENDEDORESToolStripMenuItem.Click
        VENDEDORES.ShowDialog()
    End Sub

    Private Sub INGRESODEMERCADERIAToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles INGRESODEMERCADERIAToolStripMenuItem.Click
        INGRESO_DE_MERCADERIA.ShowDialog()

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click

    End Sub

    Private Sub CONSUMIDORFINALToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CONSUMIDORFINALToolStripMenuItem.Click
        Factura_final.ShowDialog()
    End Sub

    Private Sub CLIENTESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CLIENTESToolStripMenuItem.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Text += 1
        If Label1.Text = "50" Then
            PictureBox3.Image = My.Resources.Construccion_410x268
        End If
        If Label1.Text = "100" Then
            PictureBox3.Image = My.Resources.el_area_total_aprobada_para_la_construccion_fue_menor_que_la_del_ano_pasado
        End If
        If Label1.Text = "150" Then
            PictureBox3.Image = My.Resources.industria_de_la_construccion_medium_457x325

        End If

        If Label1.Text = "200" Then
            PictureBox3.Image = My.Resources.construccion
        End If

        If Label1.Text = "250" Then
            PictureBox3.Image = My.Resources.descarga
        End If

        If Label1.Text = "300" Then
            Timer1.Stop()
            PictureBox3.Image = My.Resources.WhatsApp_Image_2019_04_02_at_9_01_41_PM
            Label1.Text = "0"
            Timer1.Start()
        End If

    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub SISTEMA_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()


    End Sub

    Private Sub NUEVOToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NUEVOToolStripMenuItem.Click
        usuarios.ShowDialog()

    End Sub

    Private Sub CONSULTADEPRODUCTOSToolStripMenuItem_Click(sender As Object, e As EventArgs)
        CONSULTA_DE_PRODUCTOS.ShowDialog()
    End Sub

    Private Sub REPORTEDEVENTASToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REPORTEDEVENTASToolStripMenuItem.Click
        reporte_de_ventas.ShowDialog()



    End Sub

    Private Sub REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REPORTEDEUBICACIONDEPRODUCTOToolStripMenuItem.Click
        reporte_de_productos.ShowDialog()

    End Sub

    Private Sub DETALLEDEPRODUCTOINGRESADOToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DETALLEDEPRODUCTOINGRESADOToolStripMenuItem.Click
        reporte_existencias.ShowDialog()


    End Sub

    Private Sub REPORTEDESALIDADEPRODUCTOToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REPORTEDESALIDADEPRODUCTOToolStripMenuItem.Click
        CONSULTA_PRODUCTOS.ShowDialog()
    End Sub

    Private Sub REPORTEDEPRODUCTOSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REPORTEDEPRODUCTOSToolStripMenuItem.Click
        reporte_de_productos.ShowDialog()

    End Sub

    Private Sub CONSULTADEPRODUCTOSToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles CONSULTADEPRODUCTOSToolStripMenuItem1.Click
        CONSULTA_DE_PRODUCTOS.ShowDialog()


    End Sub

    Private Sub CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CONSULTADEPRODUCTOSPORPROVEEDORToolStripMenuItem.Click
        CONSULTA_PRODUCTOS.ShowDialog()

    End Sub

    Private Sub CREDITOFISCALToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CREDITOFISCALToolStripMenuItem.Click
        CREDITO_FISCAL.ShowDialog()

    End Sub
End Class